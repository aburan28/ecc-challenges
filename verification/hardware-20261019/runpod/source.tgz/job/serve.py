
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import json, os
root=Path('/workspace')
token=os.environ['ECC_RESULT_TOKEN']
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_GET(self):
        prefix='/'+token+'/'
        if not self.path.startswith(prefix): self.send_error(404); return
        name=self.path[len(prefix):]
        if name=='status.json':
            stage=(root/'stage').read_text() if (root/'stage').exists() else 'starting'
            p=root/'result/controls/receipt.json'
            try: progress=json.loads(p.read_text()) if p.exists() else {}
            except ValueError: progress={}
            data=json.dumps({'stage':stage.strip(),'campaigns_completed':progress.get('campaigns_completed',0)}).encode()
        elif name in ('done','results.tgz') and (root/name).is_file(): data=(root/name).read_bytes()
        else: self.send_error(404); return
        self.send_response(200); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
HTTPServer(('0.0.0.0',8000),Handler).serve_forever()
