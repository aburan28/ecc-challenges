#!/bin/bash
set -euo pipefail
cd /workspace/source
echo compiling > /workspace/stage
mkdir -p /opt/ecc
nvcc --version > /workspace/result/compiler.txt
nvidia-smi --query-gpu=name,uuid,driver_version --format=csv,noheader > /workspace/result/device.txt
nvcc -std=c++17 -O2 -gencode arch=compute_75,code=sm_75 \
 -gencode arch=compute_80,code=sm_80 -gencode arch=compute_86,code=sm_86 \
 -gencode arch=compute_89,code=sm_89 -gencode arch=compute_90,code=sm_90 \
 -gencode arch=compute_100,code=sm_100 -gencode arch=compute_120,code=sm_120 \
 -gencode arch=compute_75,code=compute_75 worker/generic/engine.cu -o /opt/ecc/generic-engine
g++ -std=c++17 -O2 -fopenmp -x c++ worker/generic/engine.cu -o /opt/ecc/generic-engine-cpu
/opt/ecc/generic-engine --self-test
/opt/ecc/generic-engine-cpu --self-test
export PYTHONPATH=/workspace/source/src:/workspace/source/worker
export ECC_BACKEND=cuda ECC_CHECK_OUT=/workspace/result/controls OMP_NUM_THREADS=2
echo checking > /workspace/stage
python3 worker/client.py --check > /workspace/result/summary.json
echo finished > /workspace/stage
